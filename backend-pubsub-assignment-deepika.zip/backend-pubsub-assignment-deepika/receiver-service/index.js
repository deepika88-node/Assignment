const express = require('express');
const { v4: uuidv4 } = require('uuid');
const Redis = require('ioredis');
const bodyParser = require('body-parser');
const { saveToReceiverTable } = require('./db');

const app = express();
const redis = new Redis({ host: 'redis' });
app.use(bodyParser.json());

app.post('/receiver', async (req, res) => {
  const { username, class: userClass, age, email } = req.body;

  if (!username || !userClass || !Number.isInteger(age) || !email.includes('@')) {
    return res.status(400).json({ message: 'Invalid input' });
  }

  const id = uuidv4();
  const inserted_at = new Date().toISOString();
  const record = { id, username, class: userClass, age, email, inserted_at };

  try {
    await saveToReceiverTable(record);
    await redis.publish('user-data', JSON.stringify(record));
    res.json({ message: 'Data received, stored and published', record });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

app.listen(3000, () => {
  console.log('Receiver service running on port 3000');
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection:', reason);
});
