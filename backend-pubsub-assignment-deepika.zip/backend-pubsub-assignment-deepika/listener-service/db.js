const { Pool } = require('pg');

const pool = new Pool({
  host: 'postgres',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'postgres',
});

const saveToListenerTable = async ({ id, username, class: userClass, age, email, inserted_at, modified_at }) => {
  const query = `
    INSERT INTO listener_table (id, username, class, age, email, inserted_at, modified_at)
    VALUES ($1, $2, $3, $4, $5, $6, $7)
  `;
  await pool.query(query, [id, username, userClass, age, email, inserted_at, modified_at]);
};

module.exports = {
  saveToListenerTable,
};

