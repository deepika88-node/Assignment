const Redis = require('ioredis');
const { saveToListenerTable } = require('./db');

const redis = new Redis({ host: 'redis' });

redis.subscribe('user-data', () => {
  console.log('Subscribed to user-data channel');
});

redis.on('message', async (channel, message) => {
  const data = JSON.parse(message);
  const modified_at = new Date().toISOString();
  const updatedRecord = { ...data, modified_at };

  try {
    await saveToListenerTable(updatedRecord);
    console.log('Saved to Listener Table:', updatedRecord);
  } catch (err) {
    console.error('DB error:', err);
  }
});
